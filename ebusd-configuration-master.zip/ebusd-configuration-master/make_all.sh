#!/bin/sh
./make_debian.sh de
./make_debian.sh en
./make_tgz.sh de
./make_tgz.sh en
