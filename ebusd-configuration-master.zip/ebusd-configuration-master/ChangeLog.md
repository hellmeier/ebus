# 2018-12-25

* added heating circuit 3 and zone 3 to vaillant/15.700 and corrected english names

